-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: students.cah.ucf.edu
-- Generation Time: Nov 15, 2018 at 02:44 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dig4530c_group02`
--

-- --------------------------------------------------------

--
-- Table structure for table `bb_users`
--

CREATE TABLE `bb_users` (
  `customer_id` varchar(500) NOT NULL,
  `type` varchar(255) NOT NULL,
  `first_name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `last_name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(500) NOT NULL,
  `state` varchar(500) NOT NULL,
  `country` varchar(500) NOT NULL,
  `zip` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bb_users`
--

INSERT INTO `bb_users` (`customer_id`, `type`, `first_name`, `username`, `password`, `last_name`, `email`, `address`, `city`, `state`, `country`, `zip`) VALUES
('', 'admin', 'Thalia', 'th402780', '$2y$10$Qv/ryBcqqvDREOWmfMigV.8rSO9SWwhKAOQaynEoVuZwpokFGHS4O', 'Su', 'thalia989231@knights.ucf.edu', '', '', '', '', ''),
('1', 'client', 'first', 'user', 'hashedPwd', 'last', 'email', '', '', '', '', ''),
('5bed0b2414f17', 'client', 'Tow', 'Mater', '$2y$10$3f14halkjlOuVbmz1eUqEOoz8CUJTiKBNoAvzYo950uOF03bsfj.2', 'Mater', 'mater@rustyz.com', '', '', '', '', ''),
('5bed0e4a90434', 'admin', 'Admin', 'Admin', '$2y$10$zrJC/iE36df8UyEWbXGSwumVi9gWfw4wWpCbEztuKK2itv9z1FZhy', 'Administrator', 'admin@nation.com', '', '', '', '', ''),
('boujee@bb.com', 'client', 'Test', 'Test', '$2y$10$xBcr8WJPdGfUALoG7kJZfeR4hCRJYCloibk.eIsJA0uUGMx46412a', 'Test', 'boujee@bb.com', '', '', '', '', ''),
('cus_DxOcvK8epVZeYl', 'client', 'Jake', 'test', '', 'Young', 'jake@young.com', '95 Miles Avenue', 'Brooklyn', 'NY', 'United States', '54785'),
('cus_DxOhvaQ338ggi1', 'client', 'Willie', '', '', 'Muse', 'aortman@knights.ucf.edu', '1239 North Avenue', 'Brooklyn', 'NY', 'United States', '54785'),
('email', 'client', 'first', 'user', 'hashedPwd', 'last', 'email', '', '', '', '', ''),
('kachoww@materstowing.com', 'client', 'Lightning', 'Lightning', '$2y$10$iNi4NJNt1hMhWFbHMq4MauvhIRBgs./ni22vsgAM2h6vasGpLRNwi', 'McQueen', 'kachoww@materstowing.com', '', '', '', '', ''),
('superduper@coolville.com', 'super', 'Super', 'Super', '$2y$10$hD7VxdooeljbolCG4NanZe7bzvI3DdwaSQt/o8sOpDs13QLDG0Xw2', 'Duper', 'superduper@coolville.com', '', '', '', '', ''),
('test@testsss.org', 'client', 'Test', 'Test', '$2y$10$PpYejQU.G.Gscz63D1e/AOpuz4ew0ktQ0lsYZhjT3402Y2wAPuu4y', 'Test', 'test@testsss.org', '', '', '', '', ''),
('ulysses@sgrant.com', 'client', 'Ok', 'Broski', '$2y$10$AaomGeq28p0T7bQ7bqMnU.zadmMLAFuFgdG1/wyFeELID1OMEuyOq', 'Dokay', 'ulysses@sgrant.com', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bb_users_backup`
--

CREATE TABLE `bb_users_backup` (
  `customer_id` varchar(500) NOT NULL,
  `type` varchar(255) NOT NULL,
  `first_name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `last_name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(500) NOT NULL,
  `state` varchar(500) NOT NULL,
  `country` varchar(500) NOT NULL,
  `zip` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bb_users_backup`
--

INSERT INTO `bb_users_backup` (`customer_id`, `type`, `first_name`, `username`, `password`, `last_name`, `email`, `address`, `city`, `state`, `country`, `zip`) VALUES
('1', 'client', 'Thalia', 'th402780', '*9BE34D5B3C2B2C18261FD8F78551B486AAD545EB', 'Su', 'thalia989231@knights.ucf.edu', '', '', '', '', ''),
('cus_DxOcvK8epVZeYl', 'client', 'Jake', 'test', '', 'Young', 'jake@young.com', '95 Miles Avenue', 'Brooklyn', 'NY', 'United States', '54785'),
('cus_DxOhvaQ338ggi1', 'client', 'Willie', '', '', 'Muse', 'aortman@knights.ucf.edu', '1239 North Avenue', 'Brooklyn', 'NY', 'United States', '54785');

-- --------------------------------------------------------

--
-- Table structure for table `dropoutTable`
--

CREATE TABLE `dropoutTable` (
  `Orlando` varchar(14) DEFAULT NULL,
  `Melbourne` varchar(14) DEFAULT NULL,
  `London` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dropoutTable`
--

INSERT INTO `dropoutTable` (`Orlando`, `Melbourne`, `London`) VALUES
('12:00 midnight', '3:00 PM', '5:00 AM'),
('1:00 AM', '4:00 PM', '6:00 AM'),
('2:00 AM', '5:00 PM', '7:00 AM'),
('3:00 AM', '6:00 PM', '8:00 AM'),
('4:00 AM', '7:00 PM', '9:00 AM'),
('5:00 AM', '8:00 PM', '10:00 AM'),
('6:00 AM', '9:00 PM', '11:00 AM'),
('7:00 AM', '10:00 PM', '12:00 noon'),
('8:00 AM', '11:00 PM', '1:00 PM'),
('9:00 AM', '12:00 midnight', '2:00 PM'),
('10:00 AM', '1:00 AM', '3:00 PM'),
('11:00 AM', '2:00 AM', '4:00 PM'),
('12:00 noon', '3:00 AM', '5:00 PM'),
('1:00 PM', '4:00 AM', '6:00 PM'),
('2:00 PM', '5:00 AM', '7:00 PM'),
('3:00 PM', '6:00 AM', '8:00 PM'),
('4:00 PM', '7:00 AM', '9:00 PM'),
('5:00 PM', '8:00 AM', '10:00 PM'),
('6:00 PM', '9:00 AM', '11:00 PM'),
('7:00 PM', '10:00 AM', '12:00 midnight'),
('8:00 PM', '11:00 AM', '1:00 AM'),
('9:00 PM', '12:00 noon', '2:00 AM'),
('10:00 PM', '1:00 PM', '3:00 AM'),
('11:00 PM', '2:00 PM', '4:00 AM'),
('12:00 midnight', '3:00 PM', '5:00 AM'),
('1:00 AM', '4:00 PM', '6:00 AM'),
('2:00 AM', '5:00 PM', '7:00 AM'),
('3:00 AM', '6:00 PM', '8:00 AM'),
('4:00 AM', '7:00 PM', '9:00 AM'),
('5:00 AM', '8:00 PM', '10:00 AM'),
('6:00 AM', '9:00 PM', '11:00 AM'),
('7:00 AM', '10:00 PM', '12:00 noon'),
('8:00 AM', '11:00 PM', '1:00 PM'),
('9:00 AM', '12:00 midnight', '2:00 PM'),
('10:00 AM', '1:00 AM', '3:00 PM'),
('11:00 AM', '2:00 AM', '4:00 PM'),
('12:00 noon', '3:00 AM', '5:00 PM'),
('1:00 PM', '4:00 AM', '6:00 PM'),
('2:00 PM', '5:00 AM', '7:00 PM'),
('3:00 PM', '6:00 AM', '8:00 PM'),
('4:00 PM', '7:00 AM', '9:00 PM'),
('5:00 PM', '8:00 AM', '10:00 PM'),
('6:00 PM', '9:00 AM', '11:00 PM'),
('7:00 PM', '10:00 AM', '12:00 midnight'),
('8:00 PM', '11:00 AM', '1:00 AM'),
('9:00 PM', '12:00 noon', '2:00 AM'),
('10:00 PM', '1:00 PM', '3:00 AM'),
('11:00 PM', '2:00 PM', '4:00 AM');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(15) NOT NULL,
  `inventory_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `inventory_name`) VALUES
(1, 'Backpack'),
(2, 'Water Bottles'),
(3, 'Laptop Cases'),
(1, 'Backpack'),
(2, 'Water Bottles'),
(3, 'Laptop Cases');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `PK` int(11) NOT NULL,
  `prodName` varchar(255) NOT NULL,
  `prodBrand` varchar(255) NOT NULL,
  `prodDesc` varchar(10000) NOT NULL,
  `prodCat` varchar(255) NOT NULL,
  `prodSKU` int(50) NOT NULL,
  `prodStock` int(50) NOT NULL,
  `prodSale` varchar(20) NOT NULL,
  `prodPrice` varchar(20) NOT NULL,
  `prodImg` varchar(255) NOT NULL,
  `prodWeightLBS` decimal(5,2) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `color` varchar(50) NOT NULL,
  `size` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`PK`, `prodName`, `prodBrand`, `prodDesc`, `prodCat`, `prodSKU`, `prodStock`, `prodSale`, `prodPrice`, `prodImg`, `prodWeightLBS`, `gender`, `color`, `size`) VALUES
(1, 'Italian-made collarless blazer in stretch virgin wool', 'Hugo Boss', 'A tailored jacket by BOSS Womenswear, crafted in Italy in soft virgin wool blended with stretch for optimum comfort. This collarless jacket is cut to a regular fit with a feminine shape, and detailed with angled pockets with exposed zippers that provide a flash of contrast. Combine this two-button blazer with business pants or a pencil skirt for a sharp professional look.', 'jacket', 1, 50, '$350.00', '$495.00', 'prod_1.jpg', '0.50', 'womens', 'Black', 'Small'),
(2, 'Cropped short-sleeved top in two-tone lace', 'Hugo Boss', 'A feminine top by HUGO Womenswear, cut to a regular fit with a cropped length. Designed in two-tone lace, this top contrasts a distinctive floral pattern with a simple silhouette and an exposed zipper at the center back. Layer it over a patterned mini dress to create an unconventional print-led ensemble.', 'shirt', 2, 50, '$200.00', '$228.00', 'prod_2.jpg', '0.50', 'womens', 'Blue', 'Medium'),
(3, 'Cashmere Stripe-Knit Bow Sweater', 'Valentino', 'Spun from ultrasoft cashmere, this striped boxy crop sweater features a split back that fastens with an oversized bow to finish.', 'dress', 3, 50, '$175.00', '$200.00', 'prod_3.png', '0.50', 'womens', 'Black', 'Small'),
(4, 'Silk Jersey Draped T-Shirt', 'Ben Taverniti ', 'Ben Taverniti\'s street-born sportswear aesthetic gets the luxe treatment with addition of a lightweight silk knit. The sleek fitted design features long slim sleeves and a draped front panel that adds movement and visual texture to the basic t-shirt silhouette.', 'shirt', 4, 50, '$550.00', '$650.00', 'prod_4.png', '0.50', 'womens', 'Red', 'XX-large'),
(5, 'Ribbed joggers', 'Hermes', 'Ribbed joggers in cotton (100% cotton). Made in Italy.', 'pants', 5, 50, '$500.00', '$610.00', 'prod_5.jpg', '0.50', 'mens', 'White', 'X-large'),
(6, 'Shark Collar Silk Shirt With Cristals Print', 'Saint Laurent', 'Short-sleeved shark-collar shirt with a piped breast pocket.', 'shirt', 6, 50, '$850.00', '$900.00', 'prod_6.jpg', '0.50', 'mens', 'Red', 'Large'),
(7, 'Original Jean Jacket In Dark Dirty Vintage Blue Denim', 'Saint Laurent', 'Signature saint laurent jean jacket with subtly distressed front flap pockets and 2 waistband tabs.', 'jacket', 7, 50, '$800.00', '$890.00', 'prod_7.jpg', '0.50', 'mens', 'Blue', 'Medium'),
(8, 'Classic Fit Check Wool Three-piece Suit', 'Burberry', 'A three-piece suit shaped in our classic fit with a defined, rolled shoulder and straight, regular-rise trousers. Cut from Super 120s Prince of Wales check wool, it is fully lined in satin to ensure it sits comfortably and smoothly over shirting. Made and hand-finished in Italy, it has a half-canvas construction with several layers of natural horsehair to create a structured chest and soft lapel roll.', 'shirt', 8, 50, '$225.00', '$265.00', 'prod_8.png', '0.50', 'mens', 'Blue', 'Large'),
(9, 'Logo Print Stretch Cotton Shirt', 'Burberry', 'A logo-tagged shirt in cotton woven with a hint of stretch', 'sweater', 9, 50, '$45.15', '$129.00', 'prod_9.png', '0.50', 'womens', 'Yellow', 'X-large'),
(10, 'Graffiti Scribble Intarsia Cashmere Sweater', 'Burberry', 'A fine cashmere sweater with a dynamic graffiti scribble intarsia pattern. Striped rib trims shape the relaxed fit.', 'jacket', 10, 50, '$500.00', '$550.00', 'prod_10.png', '0.50', 'mens', 'Blue', 'XX-large');

-- --------------------------------------------------------

--
-- Table structure for table `products2`
--

CREATE TABLE `products2` (
  `backpack_id` int(15) NOT NULL,
  `inventory_name` varchar(200) NOT NULL,
  `inventory_id` int(15) NOT NULL,
  `image_name` varchar(25) NOT NULL,
  `inventory_color` varchar(25) NOT NULL,
  `inventory_price` varchar(25) NOT NULL,
  `inventory_desc` varchar(500) NOT NULL,
  `inventory_list` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products2`
--

INSERT INTO `products2` (`backpack_id`, `inventory_name`, `inventory_id`, `image_name`, `inventory_color`, `inventory_price`, `inventory_desc`, `inventory_list`) VALUES
(1, 'K&aring;nken Backpack', 1, 'backpack1.png', 'Gunmetal Blue', '$55.99', 'This Fjallraven Backpack is Simple, stylish and functional, the K&aring;nken backpack soon became a common sight in schools around the country, It is Made out of durable, lightweight Vinylon F, the K&aring;nken has a large main compartment with a large opening, two side pockets, a zippered pocket in the front, handle at the top, narrow, supple shoulder straps, a sitting pad in the pocket and logo that doubles as a reflector.', 'Top Zipper|Padded and fleece lined|Front zipper pocket|Waterproof|Pocket with headphone port|Gunmetal Blue|Price: $55.99'),
(2, 'Herschel Backpack', 1, 'backpack2.png', 'Sky Blue', '$65.99', 'A popular mountaineering silhouette, the Herschel backpack elevates an iconic style with modern functionality. This backpack is durable enough for anything you through at it whether that be hiking or traveling around the world. This backpack is made out of the toughest material we have to offer making it durable and ready to use. ', 'Magnetic strap closure with metal clips|Padded and fleece lined 15&quot; laptop sleeve|Adjustable drawstring closure|Front pocket with hidden zipper and magnetic clips|Pocket with headphone port|Waterproof material|Price: $65.99'),
(3, 'K&aring;nken Foldsack', 1, 'backpack3.png', 'Khaki Biege', '$60.99', 'Simple functional backpack in G-1000 HeavyDuty; top folds down and is attached with textile straps and metal buckles. Pocket for laptop. Made with waterproof material so it would be durable during any weather. Padded support in the back for long hours of use.  Also, With padded and fleece line 15 inch laptop sleeve.', 'Padded and fleece line 15&quot; laptop sleeve|Fold over flap with closure|Padded back support for long hours of use|Made with G-1000 heavy duty material made for outdoors activities|Two cell phone pockets inside for extra room|WaterProof material|$60.99'),
(4, 'Corkcicle', 2, 'bottle1.png', 'Covert Black', '$25.99', 'Crafted from stainless steel with proprietary triple insulation, this vacuum-sealed wonder cup just doesn&apos;t quit. It keeps your beverages cold for 9+ hours and hot for 3. Stays cold even longer with drinks containing ice &mdash; even out in the sun.  It is also Slip-proof so you don&apos;t have to worry it slipping and falling off things. ', 'Stainless Steel|Triple insulation|Slip-proof, silicone bottom|Easy-grip sides|Sliding, spill resistant lid|$25.99'),
(5, 'Corkcicle Canteen', 2, 'bottle2.png', 'Gunmetal Gray', '$30.00', 'Crafted from stainless steel with proprietary triple insulation, this vacuum-sealed wonder cup just doesn&apos;t quit. It keeps your beverages cold for 9+ hours and hot for 3. Stays cold even longer with drinks containing ice &mdash; even out in the sun.', 'Stainless Steel|Triple insulation|Easy-grip sides|Slip-proof, silicone bottom|Sliding, spill resistant lid|$30.00'),
(6, 'Corkcicle Tumbler', 2, 'bottle3.png', 'Arctic White', '$28.99', 'Enjoy your favorite cold or hot beverage anytime, anywhere. Crafted from stainless steel with proprietary triple insulation. Keeps drinks ice cold for up to 25 hours or hot for up to 12 without freezing or sweating. Cold even longer for drinks containing ice.', 'Slip-proof,silicone bottom|Easy-grip sides|Screw-on cap|Triple insulation|$28.99'),
(7, 'Herschel Case', 3, 'laptopcase1.png', 'Wooly Gray', '$35.99', 'Your Mac/PC goes where you go. Now it can travel in sleek, protected style with this Herschel 13-inch felt laptop sleeve. Designed for 13-inch laptops. The savvy sleeve can also be used with most 11-inch Ultrabook or MacBook laptops. Use the laptop sleeve as a convenient carrying case or simply as a sleeve before placing into another bag. With the high quality material used in this case you don’t have to worry about scratches because this case will protect all.', 'One giant main compartment|Two back pockets|Small compartment for accessories or tablets up to 8 inches|High-quality felt exterior|Soft suede interior for protection against scratching|Velcro Closure|Fits 13 inch laptop|$35.99'),
(8, 'Canvas Life Case', 3, 'laptopcase2.png', 'White Biege', '$30.00', 'Featuring a minimal, clean design, The canvas life case is fully padded and fleece lined. It is made with strong material that is both waterproof and shockproof that makes it easy and light to carry. Fits any laptop that is 13 inches or smaller.', 'Waterproof shockproof laptop case with pocket is easy and light to carry|Big Pocket on the front with zipper can hold any small item needed|Fits 13 inch laptop|Made with strong nylon material|$30.00'),
(9, 'Kayong Case', 3, 'laptopcase3.png', 'True Blue', '$32.99', 'Taking cues from the popular backpack style, the protective Kayong case features a timeless label design accent and reinforced base. It has an exposed metal zipper that gives it the more professional look. Also, comes with padded and fleece interior protecting your laptop when using it.', 'Padded and fleece interior|Exposed metal zipper|Engineered red and white striped tab|Classic woven label|Waterproof Material|$32.99'),
(10, 'K&aring;nken Foldsack\r\n\r\n\r\n\r\n', 1, 'backpack4.png', 'Sun Yellow', '$59.99', 'Simple functional backpack in G-1000 HeavyDuty; top folds down and is attached with textile straps and metal buckles. Pocket for laptop. Made with waterproof material so it would be durable during any weather. Padded support in the back for long hours of use.  Also, With padded and fleece line 15 inch laptop sleeve.', 'Padded and fleece line 15&quot; laptop sleeve|Fold over flap with closure|Padded back support for long hours of use|Made with G-1000 heavy duty material made for outdoors activities|Two cell phone pockets inside for extra room|WaterProof material|$60.99'),
(11, 'Herschel Backpack', 1, 'backpack5.png', 'Ocean Blue', '$55.99', 'Well equipped for school and work essentials, the Herschel backpack is designed with a versatile range of storage pockets and organizers. Perfect for anything you need to store. Has a huge front pocket with internal organizers and key clip. Also, comes with a padded laptop sleeve built in that can hold a 13 inch laptop. ', 'Custom striped fabric liner|Padded and fleece lined 13&quot; laptop sleeve|Front pocket with internal organizers and key clip|Waterproof zipper detail|Fleece lined sunglasses compartment|Pocket with headphone port|Classic woven label|$55.99'),
(12, 'Hydro Flask', 2, 'bottle4.png', 'Race Red', '$35.99', 'Be ready to take on whatever comes next. Our wide mouth top makes it simple to throw some ice into your beverage and hit the road with this easy to carry bottle size. Perfect for morning hikes, afternoon ski lessons, or evenings by the campfire, our 18 oz Wide Mouth bottle keeps your ice water ice cold for up to 24 hours or piping hot up to 12.', 'Ideal size for all-day hydration|Fits most backcountry water filters|Tempshield Insulation|Durable 18/8 Pro-Grade stainless Steel construction|BPA-Free and Phthalate-Free|Compatible with Hydro Flip&trade; Lid and wide mouth straw lid|Lifetime Warranty|$35.99'),
(13, 'Hydro Flask', 2, 'bottle5.png', 'Coral Blue', '$29.99', 'Big enough for a whole day in the backcountry, our Wide Mouth bottle is made with professional-grade stainless steel and a wider opening for faster fill. And because it’s designed with TempShield&trade; double wall vacuum insulation, it keeps your ice water refreshingly ice cold up to 24 hours and hot drinks hot up to 12. Which means you’ll always have the perfect temperature drink.', 'Large insulated water bottle for longer adventures|Fits most backcountry hydration filters|TempShield insulation eliminates condensation and keeps beverages cold|Durable 18/8 Pro-Grade Stainless Steel constructions|BPA-Free and Phthalate-Free|Compatible with Hydro Flip and Wide Mouth straw lid|Lifetime Warranty|$29.99'),
(14, 'Happyou Case', 3, 'laptopcase4.png', 'Heather Gray', '$25.99', 'Happyou Laptop case comes with a unique design that is one of a kind. Aside from that provides great protection for your laptop with the high quality polyester material that the cover is made out of. There is an easy access giant zipper that makes it easy for taking out your laptop and putting it back in.', 'Easy access giant zipper|Foam padding interior for protection|High quality polyester cover|Classic metal zipper|$25.99'),
(15, 'Starry Night Case', 3, 'laptopcase5.png', 'Deep Blue', '$35.99', 'This laptop case has a famous art piece called &quot;starry night&quot; that was created by the artist Riverer Van Gogh. Aside from the stylish look of this laptop it also provides some useful features. It has an easy to carry handle included inside. Made out of waterproof and strong lightweight material. Also provides foam padding for the interior for protection.', 'Easy to carry with handle included inside|Waterproof|Strong Lightweight material|Foam padding interior for protection|Exposed metal zipper|One giant pocket|15 inch laptop|$35.99');

-- --------------------------------------------------------

--
-- Table structure for table `products_Color`
--

CREATE TABLE `products_Color` (
  `Id` int(20) NOT NULL,
  `Color` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_Color`
--

INSERT INTO `products_Color` (`Id`, `Color`) VALUES
(1, 'White'),
(2, 'Blue'),
(3, 'Black'),
(4, 'Red'),
(5, 'Orange'),
(6, 'Yellow'),
(7, 'Purple'),
(8, 'Brown'),
(9, 'Plaid'),
(10, 'Floral'),
(11, 'Beige'),
(12, 'Gray');

-- --------------------------------------------------------

--
-- Table structure for table `products_Id`
--

CREATE TABLE `products_Id` (
  `Id` int(11) NOT NULL,
  `Brand` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_Id`
--

INSERT INTO `products_Id` (`Id`, `Brand`) VALUES
(0, 'Armani'),
(1, 'Burberry'),
(2, 'Fendi'),
(3, 'Dior'),
(4, 'Dolce & Gabbana'),
(5, 'Ralph Lauren');

-- --------------------------------------------------------

--
-- Table structure for table `products_Type`
--

CREATE TABLE `products_Type` (
  `Id` int(50) NOT NULL,
  `Product` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_Type`
--

INSERT INTO `products_Type` (`Id`, `Product`) VALUES
(0, 'Skirt'),
(1, 'Jacket'),
(2, 'Pants'),
(3, 'Sweater'),
(4, 'Shirt'),
(5, 'Jumpsuit'),
(6, 'Dress');

-- --------------------------------------------------------

--
-- Table structure for table `product_Description`
--

CREATE TABLE `product_Description` (
  `Id` int(50) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_Description`
--

INSERT INTO `product_Description` (`Id`, `Description`) VALUES
(0, 'This is a floor length elegant black formal dress brought to you from Armani. As you can see it is very sleek and form-fitting while being comfortable. It has a one shoulder sleeve and can be paired well with any heels. '),
(1, 'This is a pair of Men\'s jeans brought to you from Fendi. Nice pair of jeans to wear out or around the house. Nice and stretchy and not too tight for your comfort. '),
(2, 'This is a black and green plaid shirt brought to you from Burberry. A nice stylish long sleeve button-down shirt that looks great with the sleeves down or pushed up.'),
(3, 'This is a very stylish mens button-down shirt brought to you from Dolce & Gabbana. A very formal dressy shirt with a black and white floral pattern.'),
(4, 'This is a very nice suit jacket brought to you from Dior. Nice form fitting jacket for men going out on their date nights.'),
(5, 'This is a very comfortable sweater brought to you from Ralph Lauren. A very nice beige sweater for men. It will keep you nice and toasty while being dressy. '),
(6, 'This is a women\'s black jacket brought to you from Dior. This nice form fitting jacket will keep you warm while being stylish. '),
(7, 'This is a men\'s jacket brought to you from Dolce & Gabbana. This hoodie is very stylish and comfortable for any night out.'),
(8, 'This is a pair of men\'s gray suit pants brought to you from Armani. These stylish pants will go well with any shirt for a nice night out on the town.'),
(9, 'This is a pair of women\'s jeans brought to you from Armani. These stylish jeans can be a pair of regular jeans for going out or be converted into cute capris. '),
(10, 'This is a poncho styled jacket for women brought to you from Burberry. This stylish jacket will keep you warm and is also reversible.'),
(11, 'This is a women\'s black lace skirt brought to you from Dolce & Gabbana. This cute skirt can be worn on any outing and be very comfortable.'),
(12, 'This is a woman\'s skirt brought to you from Fendi. This plaid brown skirt can be paired with a nice shirt and be great for every day things to do.'),
(13, 'This is a white polo shirt for men brought to you from Fendi. This polo would look great with a nice pair of jeans to go out on a lunch date. '),
(14, 'This is a black men\'s sweater brought to you from Dior. This sweater is nice and warm and very stylish for any time of day. '),
(15, 'This is a men\'s trench-coat brought to you from Burberry. This gray trench-coat is very nice for those rainy cold days, while wanting to stay stylish.'),
(16, 'This is a women\'s black jacket brought to you from Dolce & Gabbana. This stylish jacket will pair with jeans or skirts for any cold weather. '),
(17, 'This is a women\'s black jumpsuit brought to you from Burberry. This jumpsuit is very comfortable with pockets for your convenience. Wear it out for a night on the town. '),
(18, 'This is a women\'s black jumpsuit brought to you from Ralph Lauren. This is a dressy casual jumpsuit that can be worn for a more formal event or for those work presentations.'),
(19, 'This is a women\'s black top brought to you from Armani. This comfortable quarter sleeve shirt would be good for those cool autumn days walking in the park.'),
(20, 'This is a women\'s plaid shirt brought to you from Fendi. This shirt is cute and can feminine and can be paired with jeans or a skirt for you dates.'),
(21, 'This is a women\'s floral skirt brought to you from Dior. This long skirt is very comfortable and stylish for summer days in the sun.');

-- --------------------------------------------------------

--
-- Table structure for table `product_Gender`
--

CREATE TABLE `product_Gender` (
  `Id` int(50) NOT NULL,
  `Gender` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_Gender`
--

INSERT INTO `product_Gender` (`Id`, `Gender`) VALUES
(0, 'Men'),
(1, 'Women');

-- --------------------------------------------------------

--
-- Table structure for table `product_Image`
--

CREATE TABLE `product_Image` (
  `Id` int(50) NOT NULL,
  `Image1` varchar(500) NOT NULL,
  `Image2` varchar(500) NOT NULL,
  `Image3` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_Image`
--

INSERT INTO `product_Image` (`Id`, `Image1`, `Image2`, `Image3`) VALUES
(0, 'https://students.cah.ucf.edu/~dig4530c_group02/images/dress_Armani1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/dress_armani2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/dress_armani3.jpg'),
(1, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jean_fendi1.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jean_fendi2.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jean_fendi3.jpeg'),
(2, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_burberry1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_burberry2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_burberry3.jpg'),
(3, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_dolce1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_dolce2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_shirt_dolce3.jpg'),
(4, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_suitjacket_dior1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_suitjacket_dior2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_suitjacket_dior3.jpg'),
(5, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_RL1.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_RL2.png', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_RL3.png'),
(6, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dior1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dior2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dior3.jpg'),
(7, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jacket_dolce1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jacket_dolce2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_jacket_dolce3.jpg'),
(8, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_pants_armani1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_pants_armani2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_pants_armani3.jpg'),
(9, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jean_armani1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jean_armani2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jean_armani3.jpg'),
(10, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_poncho_burberry1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_poncho_burberry2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_poncho_burberry3.jpg'),
(11, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dolce1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dolce2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dolce3.jpg'),
(12, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_fendi1.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_fendi2.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_fendi3.jpeg'),
(13, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_polo_fendi1.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_polo_fendi2.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_polo_fendi3.jpeg'),
(14, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_dior1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_dior2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_sweater_dior3.jpg'),
(15, 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_trenchcoat_burberry1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_trenchcoat_burberry2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/men_trenchcoat_burberry3.jpg'),
(16, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dolce1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dolce2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jacket_dolce3.jpg'),
(17, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_burberry1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_burberry2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_burberry3.jpg'),
(18, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_RL1.png', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_RL2.png', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_jumpsuit_RL3.png'),
(19, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_armani1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_armani2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_armani3.jpg'),
(20, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_fendi1.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_fendi2.jpeg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_shirt_fendi3.jpeg'),
(21, 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dior1.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dior2.jpg', 'https://students.cah.ucf.edu/~dig4530c_group02/images/women_skirt_dior3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_Price`
--

CREATE TABLE `product_Price` (
  `Id` int(50) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_Price`
--

INSERT INTO `product_Price` (`Id`, `Price`) VALUES
(0, 200),
(1, 50),
(2, 45),
(3, 67),
(4, 150),
(5, 54),
(6, 89),
(7, 105),
(8, 95),
(9, 44),
(10, 158),
(11, 74),
(12, 66),
(13, 43),
(14, 77),
(15, 99),
(16, 76),
(17, 123),
(18, 156),
(19, 54),
(20, 48),
(21, 63);

-- --------------------------------------------------------

--
-- Table structure for table `product_Size`
--

CREATE TABLE `product_Size` (
  `Id` int(50) NOT NULL,
  `Size` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_Size`
--

INSERT INTO `product_Size` (`Id`, `Size`) VALUES
(0, 'Small'),
(1, 'Medium'),
(2, 'Large'),
(3, 'X-Large'),
(4, 'XX-Large');

-- --------------------------------------------------------

--
-- Table structure for table `Stock`
--

CREATE TABLE `Stock` (
  `Id` int(50) NOT NULL,
  `prodBrand` int(50) NOT NULL,
  `prodType` int(50) NOT NULL,
  `prodDescription` int(50) NOT NULL,
  `prodPrice` int(50) NOT NULL,
  `prodColor` int(50) NOT NULL,
  `prodSize` int(50) NOT NULL,
  `prodImage` int(50) NOT NULL,
  `prodStock` int(50) NOT NULL,
  `prodGender` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Stock`
--

INSERT INTO `Stock` (`Id`, `prodBrand`, `prodType`, `prodDescription`, `prodPrice`, `prodColor`, `prodSize`, `prodImage`, `prodStock`, `prodGender`) VALUES
(0, 0, 6, 0, 0, 3, 1, 0, 2, 1),
(1, 2, 2, 1, 1, 2, 2, 1, 5, 0),
(2, 1, 4, 2, 2, 9, 3, 2, 7, 0),
(3, 4, 4, 3, 3, 10, 1, 3, 3, 0),
(4, 3, 1, 4, 4, 3, 0, 4, 4, 0),
(5, 5, 3, 5, 5, 11, 2, 5, 5, 0),
(6, 3, 1, 6, 6, 3, 0, 6, 6, 1),
(7, 4, 1, 7, 7, 3, 0, 7, 7, 0),
(8, 0, 2, 8, 8, 3, 3, 8, 5, 0),
(9, 0, 2, 9, 9, 2, 2, 9, 8, 1),
(10, 1, 1, 10, 10, 5, 3, 10, 9, 1),
(11, 4, 0, 11, 11, 3, 1, 11, 8, 1),
(12, 2, 0, 12, 12, 9, 1, 12, 6, 1),
(13, 2, 4, 13, 13, 1, 1, 13, 6, 0),
(14, 3, 3, 14, 14, 3, 0, 14, 2, 0),
(15, 1, 1, 15, 15, 3, 2, 15, 3, 0),
(16, 4, 1, 16, 16, 3, 2, 16, 4, 1),
(17, 1, 5, 17, 17, 3, 4, 17, 1, 1),
(18, 5, 5, 18, 18, 3, 0, 18, 2, 1),
(19, 0, 4, 19, 19, 3, 3, 19, 4, 1),
(20, 2, 4, 20, 20, 9, 0, 20, 8, 1),
(21, 3, 0, 21, 21, 10, 2, 21, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(99) NOT NULL,
  `item` int(25) NOT NULL,
  `category` int(25) NOT NULL,
  `color` int(25) NOT NULL,
  `size` int(25) NOT NULL,
  `stock` int(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `item`, `category`, `color`, `size`, `stock`) VALUES
(1, 1, 1, 3, 0, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bb_users`
--
ALTER TABLE `bb_users`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `bb_users_backup`
--
ALTER TABLE `bb_users_backup`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`PK`);

--
-- Indexes for table `products2`
--
ALTER TABLE `products2`
  ADD UNIQUE KEY `backpack_id` (`backpack_id`);

--
-- Indexes for table `products_Color`
--
ALTER TABLE `products_Color`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `products_Id`
--
ALTER TABLE `products_Id`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `products_Type`
--
ALTER TABLE `products_Type`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_Description`
--
ALTER TABLE `product_Description`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_Gender`
--
ALTER TABLE `product_Gender`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_Image`
--
ALTER TABLE `product_Image`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_Price`
--
ALTER TABLE `product_Price`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product_Size`
--
ALTER TABLE `product_Size`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Stock`
--
ALTER TABLE `Stock`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Brand` (`prodBrand`),
  ADD KEY `Color` (`prodColor`),
  ADD KEY `Description` (`prodDescription`),
  ADD KEY `Image` (`prodImage`),
  ADD KEY `Price` (`prodPrice`),
  ADD KEY `Size` (`prodSize`),
  ADD KEY `Type` (`prodType`),
  ADD KEY `Gender` (`prodGender`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`item`),
  ADD KEY `category` (`category`),
  ADD KEY `color` (`color`),
  ADD KEY `size` (`size`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `PK` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products_Color`
--
ALTER TABLE `products_Color`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Stock`
--
ALTER TABLE `Stock`
  ADD CONSTRAINT `Stock_ibfk_1` FOREIGN KEY (`prodBrand`) REFERENCES `products_Id` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_2` FOREIGN KEY (`prodColor`) REFERENCES `products_Color` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_3` FOREIGN KEY (`prodDescription`) REFERENCES `product_Description` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_4` FOREIGN KEY (`prodImage`) REFERENCES `product_Image` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_5` FOREIGN KEY (`prodPrice`) REFERENCES `product_Price` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_6` FOREIGN KEY (`prodSize`) REFERENCES `product_Size` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_7` FOREIGN KEY (`prodType`) REFERENCES `products_Type` (`Id`),
  ADD CONSTRAINT `Stock_ibfk_8` FOREIGN KEY (`prodGender`) REFERENCES `product_Gender` (`Id`);

--
-- Constraints for table `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_ibfk_1` FOREIGN KEY (`item`) REFERENCES `products` (`PK`),
  ADD CONSTRAINT `test_ibfk_2` FOREIGN KEY (`category`) REFERENCES `products_Type` (`Id`),
  ADD CONSTRAINT `test_ibfk_3` FOREIGN KEY (`color`) REFERENCES `products_Color` (`Id`),
  ADD CONSTRAINT `test_ibfk_4` FOREIGN KEY (`size`) REFERENCES `product_Size` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
